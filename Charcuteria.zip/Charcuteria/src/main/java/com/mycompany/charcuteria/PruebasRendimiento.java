/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.charcuteria;

/**
 *
 * @author david.b
 */


import java.util.Random;

public class PruebasRendimiento {
    public void ejecutarPruebas(GestionCharcuteria gestionCharcuteria) {
        Random random = new Random();

        // Crear datos de prueba
        for (int i = 0; i < 1000; i++) {
            String nombre = "Producto" + i;
            double precioPorKilo = 10 + random.nextDouble() * 90; // Precio entre 10 y 100
            double pesoDisponible = 10 + random.nextDouble() * 90; // Peso entre 10 y 100 kg
            gestionCharcuteria.agregarProducto(nombre, precioPorKilo, pesoDisponible);
        }

        // Medir el tiempo para mostrar el inventario
        long inicio = System.nanoTime();
        gestionCharcuteria.mostrarInventario();
        long fin = System.nanoTime();
        System.out.println("Tiempo para mostrar el inventario: " + (fin - inicio) / 1_000_000.0 + " ms");

        // Medir el tiempo para vender un producto existente
        inicio = System.nanoTime();
        gestionCharcuteria.venderProducto("Producto500", 5);
        fin = System.nanoTime();
        System.out.println("Tiempo para vender un producto existente: " + (fin - inicio) / 1_000_000.0 + " ms");

        // Medir el tiempo para vender un producto no existente
        inicio = System.nanoTime();
        gestionCharcuteria.venderProducto("ProductoNoExistente", 5);
        fin = System.nanoTime();
        System.out.println("Tiempo para vender un producto no existente: " + (fin - inicio) / 1_000_000.0 + " ms");

        // Medir el tiempo para agregar un nuevo producto
        inicio = System.nanoTime();
        gestionCharcuteria.agregarProducto("ProductoNuevo", 50, 50);
        fin = System.nanoTime();
        System.out.println("Tiempo para agregar un nuevo producto: " + (fin - inicio) / 1_000_000.0 + " ms");
    }
}
