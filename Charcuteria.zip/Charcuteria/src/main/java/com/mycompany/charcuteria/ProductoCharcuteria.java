/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.charcuteria;

/**
 *
 * @author david.b
 */
 public  class  ProductoCharcuteria {
    private String nombre;
    private double precioPorKilo;
    private double pesoDisponible;
    
    //Constructor
    /**
     * 
     * @param nombre Nombre especificado como un String
     * @param precioPorKilo Valor especificado como un double(precio en euros y el peso por kg)
     * @param pesoDisponible Valor especificado como un double (peso disponible en venta)
     */

    public ProductoCharcuteria(String nombre, double precioPorKilo, double pesoDisponible) {
        this.nombre = nombre;
        this.precioPorKilo = precioPorKilo;
        this.pesoDisponible = pesoDisponible;
    }
    
    /**
     * 
     * @return 
     */

    public String getNombre() {
        return nombre;
    }

    public double getPrecioPorKilo() {
        return precioPorKilo;
    }

    public double getPesoDisponible() {
        return pesoDisponible;
    }
    
    /**
     * Nos permite la venta de un producto con un peso específico
     * @param peso (Se utiliza para saber el peso del producto que vendemos)
     * @see <a href="GestionCharcuteria.html#agregarProducto">peso</a>
     */

    public void venderProducto(double peso) {
        if (peso <= pesoDisponible) {
            pesoDisponible -= peso;
            System.out.println("Producto vendido: " + nombre + " (" + peso + " kg)");
        } else {
            System.out.println("No hay suficiente peso disponible de " + nombre);
        }
    }
    
    /**
     * Este método  incluye el nombre del producto, el precio por kilo, y el peso disponible del producto.   
     * 
     * @return Una cadena que respresenta el objeto.
     */

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Precio por Kilo: $" + precioPorKilo + ", Peso Disponible: " + pesoDisponible + " kg";
    }
}