/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.charcuteria;

/**
 *
 * @author david.b
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

class ProductoCharcuteria {
    private String nombre;
    private double precioPorKilo;
    private double pesoDisponible;

    public ProductoCharcuteria(String nombre, double precioPorKilo, double pesoDisponible) {
        this.nombre = nombre;
        this.precioPorKilo = precioPorKilo;
        this.pesoDisponible = pesoDisponible;
    }

    public String getNombre() {
        return nombre;
    }

    public double getPrecioPorKilo() {
        return precioPorKilo;
    }

    public double getPesoDisponible() {
        return pesoDisponible;
    }

    public void venderProducto(double peso) {
        if (peso <= pesoDisponible) {
            pesoDisponible -= peso;
            System.out.println("Producto vendido: " + nombre + " (" + peso + " kg)");
        } else {
            System.out.println("No hay suficiente peso disponible de " + nombre);
        }
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + ", Precio por Kilo: $" + precioPorKilo + ", Peso Disponible: " + pesoDisponible + " kg";
    }
}

public class GestionCharcuteria {
    private Map<String, ProductoCharcuteria> inventario;

    public GestionCharcuteria() {
        inventario = new HashMap<>();
    }

    public void agregarProducto(String nombre, double precioPorKilo, double pesoDisponible) {
        if (inventario.containsKey(nombre)) {
            System.out.println("Ya existe un producto con ese nombre en el inventario.");
            return;
        }

        ProductoCharcuteria nuevoProducto = new ProductoCharcuteria(nombre, precioPorKilo, pesoDisponible);
        inventario.put(nombre, nuevoProducto);
        System.out.println("Producto agregado: " + nuevoProducto);
    }

    public void mostrarInventario() {
        if (inventario.isEmpty()) {
            System.out.println("El inventario está vacío.");
        } else {
            System.out.println("Inventario de la charcutería:");
            for (ProductoCharcuteria producto : inventario.values()) {
                System.out.println(producto);
            }
        }
    }

    public void venderProducto(String nombre, double peso) {
        ProductoCharcuteria producto = inventario.get(nombre);
        if (producto != null) {
            producto.venderProducto(peso);
        } else {
            System.out.println("Producto no encontrado en el inventario.");
        }
    }

    public static void main(String[] args) {
        GestionCharcuteria gestionCharcuteria = new GestionCharcuteria();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1. Agregar producto al inventario");
            System.out.println("2. Mostrar inventario de la charcutería");
            System.out.println("3. Vender producto");
            System.out.println("4. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion;
            try {
                opcion = scanner.nextInt();
                scanner.nextLine(); // Consumir el salto de línea después del número
            } catch (Exception e) {
                System.out.println("Opción no válida. Intente de nuevo.");
                scanner.nextLine(); // Limpiar el buffer de entrada
                continue;
            }

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nombre del producto: ");
                    String nombre = scanner.nextLine();
                    System.out.print("Ingrese el precio por kilo del producto: $");
                    double precioPorKilo;
                    try {
                        precioPorKilo = scanner.nextDouble();
                        scanner.nextLine(); // Consumir el salto de línea después del número
                    } catch (Exception e) {
                        System.out.println("Precio no válido. Intente de nuevo.");
                        scanner.nextLine(); // Limpiar el buffer de entrada
                        break;
                    }
                    System.out.print("Ingrese el peso disponible del producto en kilos: ");
                    double peso;
                    try {
                        peso = scanner.nextDouble();
                        scanner.nextLine(); // Consumir el salto de línea después del número
                    } catch (Exception e) {
                        System.out.println("Peso no válido. Intente de nuevo.");
                        scanner.nextLine(); // Limpiar el buffer de entrada
                        break;
                    }
                    gestionCharcuteria.agregarProducto(nombre, precioPorKilo, peso);
                    break;
                case 2:
                    gestionCharcuteria.mostrarInventario();
                    break;
                case 3:
                    System.out.print("Ingrese el nombre del producto a vender: ");
                    String productoVender = scanner.nextLine();
                    System.out.print("Ingrese el peso a vender en kilos: ");
                    double pesoVender;
                    try {
                        pesoVender = scanner.nextDouble();
                        scanner.nextLine(); // Consumir el salto de línea después del número
                    } catch (Exception e) {
                        System.out.println("Peso no válido. Intente de nuevo.");
                        scanner.nextLine(); // Limpiar el buffer de entrada
                        break;
                    }
                    gestionCharcuteria.venderProducto(productoVender, pesoVender);
                    break;
                case 4:
                    System.out.println("Saliendo del programa.");
                    scanner.close(); // Cerrar el scanner antes de salir
                    System.exit(0);
                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }
    }
}
